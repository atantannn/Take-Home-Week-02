﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb1_kata1 = new System.Windows.Forms.Label();
            this.lb_kata2 = new System.Windows.Forms.Label();
            this.lb_kata3 = new System.Windows.Forms.Label();
            this.lb_kata4 = new System.Windows.Forms.Label();
            this.lb_kata5 = new System.Windows.Forms.Label();
            this.txtbox_kata1 = new System.Windows.Forms.TextBox();
            this.txtbox_kata2 = new System.Windows.Forms.TextBox();
            this.txtbox_kata3 = new System.Windows.Forms.TextBox();
            this.txtbox_kata4 = new System.Windows.Forms.TextBox();
            this.txtbox_kata5 = new System.Windows.Forms.TextBox();
            this.btn_play = new System.Windows.Forms.Button();
            this.panel_kata = new System.Windows.Forms.Panel();
            this.btn_Q = new System.Windows.Forms.Button();
            this.btn_W = new System.Windows.Forms.Button();
            this.panel_keyboard = new System.Windows.Forms.Panel();
            this.lb_kataditebak = new System.Windows.Forms.Label();
            this.btn_M = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.btn_Z = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_i = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.lb_blank5 = new System.Windows.Forms.Label();
            this.lb_blank4 = new System.Windows.Forms.Label();
            this.lb_blank3 = new System.Windows.Forms.Label();
            this.lb_blank2 = new System.Windows.Forms.Label();
            this.lb_blank1 = new System.Windows.Forms.Label();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.panel_kata.SuspendLayout();
            this.panel_keyboard.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb1_kata1
            // 
            this.lb1_kata1.AutoSize = true;
            this.lb1_kata1.Location = new System.Drawing.Point(6, 14);
            this.lb1_kata1.Name = "lb1_kata1";
            this.lb1_kata1.Size = new System.Drawing.Size(50, 16);
            this.lb1_kata1.TabIndex = 0;
            this.lb1_kata1.Text = "Word 1";
            // 
            // lb_kata2
            // 
            this.lb_kata2.AutoSize = true;
            this.lb_kata2.Location = new System.Drawing.Point(6, 56);
            this.lb_kata2.Name = "lb_kata2";
            this.lb_kata2.Size = new System.Drawing.Size(50, 16);
            this.lb_kata2.TabIndex = 1;
            this.lb_kata2.Text = "Word 2";
            // 
            // lb_kata3
            // 
            this.lb_kata3.AutoSize = true;
            this.lb_kata3.Location = new System.Drawing.Point(6, 98);
            this.lb_kata3.Name = "lb_kata3";
            this.lb_kata3.Size = new System.Drawing.Size(50, 16);
            this.lb_kata3.TabIndex = 2;
            this.lb_kata3.Text = "Word 3";
            // 
            // lb_kata4
            // 
            this.lb_kata4.AutoSize = true;
            this.lb_kata4.Location = new System.Drawing.Point(6, 141);
            this.lb_kata4.Name = "lb_kata4";
            this.lb_kata4.Size = new System.Drawing.Size(50, 16);
            this.lb_kata4.TabIndex = 3;
            this.lb_kata4.Text = "Word 4";
            // 
            // lb_kata5
            // 
            this.lb_kata5.AutoSize = true;
            this.lb_kata5.Location = new System.Drawing.Point(6, 176);
            this.lb_kata5.Name = "lb_kata5";
            this.lb_kata5.Size = new System.Drawing.Size(50, 16);
            this.lb_kata5.TabIndex = 4;
            this.lb_kata5.Text = "Word 5";
            // 
            // txtbox_kata1
            // 
            this.txtbox_kata1.Location = new System.Drawing.Point(78, 14);
            this.txtbox_kata1.Name = "txtbox_kata1";
            this.txtbox_kata1.Size = new System.Drawing.Size(127, 22);
            this.txtbox_kata1.TabIndex = 5;
            // 
            // txtbox_kata2
            // 
            this.txtbox_kata2.Location = new System.Drawing.Point(78, 56);
            this.txtbox_kata2.Name = "txtbox_kata2";
            this.txtbox_kata2.Size = new System.Drawing.Size(127, 22);
            this.txtbox_kata2.TabIndex = 6;
            // 
            // txtbox_kata3
            // 
            this.txtbox_kata3.Location = new System.Drawing.Point(78, 98);
            this.txtbox_kata3.Name = "txtbox_kata3";
            this.txtbox_kata3.Size = new System.Drawing.Size(127, 22);
            this.txtbox_kata3.TabIndex = 7;
            // 
            // txtbox_kata4
            // 
            this.txtbox_kata4.Location = new System.Drawing.Point(78, 141);
            this.txtbox_kata4.Name = "txtbox_kata4";
            this.txtbox_kata4.Size = new System.Drawing.Size(127, 22);
            this.txtbox_kata4.TabIndex = 8;
            // 
            // txtbox_kata5
            // 
            this.txtbox_kata5.Location = new System.Drawing.Point(78, 176);
            this.txtbox_kata5.Name = "txtbox_kata5";
            this.txtbox_kata5.Size = new System.Drawing.Size(127, 22);
            this.txtbox_kata5.TabIndex = 9;
            // 
            // btn_play
            // 
            this.btn_play.Font = new System.Drawing.Font("MV Boli", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_play.Location = new System.Drawing.Point(88, 219);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(97, 31);
            this.btn_play.TabIndex = 10;
            this.btn_play.Text = "Play!";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // panel_kata
            // 
            this.panel_kata.Controls.Add(this.txtbox_kata3);
            this.panel_kata.Controls.Add(this.btn_play);
            this.panel_kata.Controls.Add(this.lb1_kata1);
            this.panel_kata.Controls.Add(this.txtbox_kata5);
            this.panel_kata.Controls.Add(this.lb_kata2);
            this.panel_kata.Controls.Add(this.txtbox_kata4);
            this.panel_kata.Controls.Add(this.lb_kata3);
            this.panel_kata.Controls.Add(this.lb_kata4);
            this.panel_kata.Controls.Add(this.txtbox_kata2);
            this.panel_kata.Controls.Add(this.lb_kata5);
            this.panel_kata.Controls.Add(this.txtbox_kata1);
            this.panel_kata.Location = new System.Drawing.Point(23, 44);
            this.panel_kata.Name = "panel_kata";
            this.panel_kata.Size = new System.Drawing.Size(233, 278);
            this.panel_kata.TabIndex = 11;
            this.panel_kata.VisibleChanged += new System.EventHandler(this.Form1_Load);
            // 
            // btn_Q
            // 
            this.btn_Q.Location = new System.Drawing.Point(136, 158);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(40, 38);
            this.btn_Q.TabIndex = 12;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = true;
            this.btn_Q.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_W
            // 
            this.btn_W.Location = new System.Drawing.Point(181, 158);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(40, 38);
            this.btn_W.TabIndex = 13;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = true;
            this.btn_W.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // panel_keyboard
            // 
            this.panel_keyboard.Controls.Add(this.lb_kataditebak);
            this.panel_keyboard.Controls.Add(this.btn_M);
            this.panel_keyboard.Controls.Add(this.btn_N);
            this.panel_keyboard.Controls.Add(this.btn_B);
            this.panel_keyboard.Controls.Add(this.btn_V);
            this.panel_keyboard.Controls.Add(this.btn_C);
            this.panel_keyboard.Controls.Add(this.btn_X);
            this.panel_keyboard.Controls.Add(this.btn_Z);
            this.panel_keyboard.Controls.Add(this.btn_L);
            this.panel_keyboard.Controls.Add(this.btn_K);
            this.panel_keyboard.Controls.Add(this.btn_J);
            this.panel_keyboard.Controls.Add(this.btn_H);
            this.panel_keyboard.Controls.Add(this.btn_G);
            this.panel_keyboard.Controls.Add(this.btn_F);
            this.panel_keyboard.Controls.Add(this.btn_D);
            this.panel_keyboard.Controls.Add(this.btn_S);
            this.panel_keyboard.Controls.Add(this.btn_A);
            this.panel_keyboard.Controls.Add(this.btn_P);
            this.panel_keyboard.Controls.Add(this.btn_O);
            this.panel_keyboard.Controls.Add(this.btn_i);
            this.panel_keyboard.Controls.Add(this.btn_U);
            this.panel_keyboard.Controls.Add(this.lb_blank5);
            this.panel_keyboard.Controls.Add(this.lb_blank4);
            this.panel_keyboard.Controls.Add(this.lb_blank3);
            this.panel_keyboard.Controls.Add(this.lb_blank2);
            this.panel_keyboard.Controls.Add(this.lb_blank1);
            this.panel_keyboard.Controls.Add(this.btn_Y);
            this.panel_keyboard.Controls.Add(this.btn_T);
            this.panel_keyboard.Controls.Add(this.btn_R);
            this.panel_keyboard.Controls.Add(this.btn_E);
            this.panel_keyboard.Controls.Add(this.btn_W);
            this.panel_keyboard.Controls.Add(this.btn_Q);
            this.panel_keyboard.Location = new System.Drawing.Point(166, 30);
            this.panel_keyboard.Name = "panel_keyboard";
            this.panel_keyboard.Size = new System.Drawing.Size(1124, 498);
            this.panel_keyboard.TabIndex = 14;
            // 
            // lb_kataditebak
            // 
            this.lb_kataditebak.AutoSize = true;
            this.lb_kataditebak.Location = new System.Drawing.Point(599, 90);
            this.lb_kataditebak.Name = "lb_kataditebak";
            this.lb_kataditebak.Size = new System.Drawing.Size(44, 16);
            this.lb_kataditebak.TabIndex = 43;
            this.lb_kataditebak.Text = "label1";
            // 
            // btn_M
            // 
            this.btn_M.Location = new System.Drawing.Point(482, 258);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(40, 38);
            this.btn_M.TabIndex = 42;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = true;
            this.btn_M.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_N
            // 
            this.btn_N.Location = new System.Drawing.Point(434, 258);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(40, 38);
            this.btn_N.TabIndex = 41;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = true;
            this.btn_N.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_B
            // 
            this.btn_B.Location = new System.Drawing.Point(385, 258);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(40, 38);
            this.btn_B.TabIndex = 40;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = true;
            this.btn_B.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_V
            // 
            this.btn_V.Location = new System.Drawing.Point(332, 258);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(40, 38);
            this.btn_V.TabIndex = 39;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = true;
            this.btn_V.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_C
            // 
            this.btn_C.Location = new System.Drawing.Point(282, 258);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(40, 38);
            this.btn_C.TabIndex = 38;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_X
            // 
            this.btn_X.Location = new System.Drawing.Point(228, 258);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(40, 38);
            this.btn_X.TabIndex = 37;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = true;
            this.btn_X.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_Z
            // 
            this.btn_Z.Location = new System.Drawing.Point(179, 258);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(40, 38);
            this.btn_Z.TabIndex = 36;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = true;
            this.btn_Z.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_L
            // 
            this.btn_L.Location = new System.Drawing.Point(529, 205);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(40, 38);
            this.btn_L.TabIndex = 35;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = true;
            this.btn_L.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_K
            // 
            this.btn_K.Location = new System.Drawing.Point(482, 205);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(40, 38);
            this.btn_K.TabIndex = 34;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = true;
            this.btn_K.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_J
            // 
            this.btn_J.Location = new System.Drawing.Point(434, 205);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(40, 38);
            this.btn_J.TabIndex = 33;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = true;
            this.btn_J.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_H
            // 
            this.btn_H.Location = new System.Drawing.Point(386, 205);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(40, 38);
            this.btn_H.TabIndex = 32;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = true;
            this.btn_H.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_G
            // 
            this.btn_G.Location = new System.Drawing.Point(339, 205);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(40, 38);
            this.btn_G.TabIndex = 31;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = true;
            this.btn_G.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_F
            // 
            this.btn_F.Location = new System.Drawing.Point(290, 205);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(40, 38);
            this.btn_F.TabIndex = 30;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = true;
            this.btn_F.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_D
            // 
            this.btn_D.Location = new System.Drawing.Point(243, 205);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(40, 38);
            this.btn_D.TabIndex = 29;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = true;
            this.btn_D.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_S
            // 
            this.btn_S.Location = new System.Drawing.Point(197, 205);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(40, 38);
            this.btn_S.TabIndex = 28;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = true;
            this.btn_S.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_A
            // 
            this.btn_A.Location = new System.Drawing.Point(151, 205);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(40, 38);
            this.btn_A.TabIndex = 27;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = true;
            this.btn_A.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_P
            // 
            this.btn_P.Location = new System.Drawing.Point(547, 158);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(37, 38);
            this.btn_P.TabIndex = 26;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = true;
            this.btn_P.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_O
            // 
            this.btn_O.Location = new System.Drawing.Point(499, 158);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(40, 38);
            this.btn_O.TabIndex = 25;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = true;
            this.btn_O.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_i
            // 
            this.btn_i.Location = new System.Drawing.Point(453, 158);
            this.btn_i.Name = "btn_i";
            this.btn_i.Size = new System.Drawing.Size(40, 38);
            this.btn_i.TabIndex = 24;
            this.btn_i.Text = "I";
            this.btn_i.UseVisualStyleBackColor = true;
            this.btn_i.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_U
            // 
            this.btn_U.Location = new System.Drawing.Point(408, 159);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(40, 38);
            this.btn_U.TabIndex = 23;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = true;
            this.btn_U.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // lb_blank5
            // 
            this.lb_blank5.AutoSize = true;
            this.lb_blank5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blank5.Location = new System.Drawing.Point(450, 114);
            this.lb_blank5.Name = "lb_blank5";
            this.lb_blank5.Size = new System.Drawing.Size(47, 16);
            this.lb_blank5.TabIndex = 22;
            this.lb_blank5.Text = "_____";
            // 
            // lb_blank4
            // 
            this.lb_blank4.AutoSize = true;
            this.lb_blank4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blank4.Location = new System.Drawing.Point(391, 114);
            this.lb_blank4.Name = "lb_blank4";
            this.lb_blank4.Size = new System.Drawing.Size(47, 16);
            this.lb_blank4.TabIndex = 21;
            this.lb_blank4.Text = "_____";
            // 
            // lb_blank3
            // 
            this.lb_blank3.AutoSize = true;
            this.lb_blank3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blank3.Location = new System.Drawing.Point(333, 114);
            this.lb_blank3.Name = "lb_blank3";
            this.lb_blank3.Size = new System.Drawing.Size(47, 16);
            this.lb_blank3.TabIndex = 20;
            this.lb_blank3.Text = "_____";
            // 
            // lb_blank2
            // 
            this.lb_blank2.AutoSize = true;
            this.lb_blank2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blank2.Location = new System.Drawing.Point(273, 114);
            this.lb_blank2.Name = "lb_blank2";
            this.lb_blank2.Size = new System.Drawing.Size(47, 16);
            this.lb_blank2.TabIndex = 19;
            this.lb_blank2.Text = "_____";
            // 
            // lb_blank1
            // 
            this.lb_blank1.AutoSize = true;
            this.lb_blank1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blank1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lb_blank1.Location = new System.Drawing.Point(213, 114);
            this.lb_blank1.Name = "lb_blank1";
            this.lb_blank1.Size = new System.Drawing.Size(47, 16);
            this.lb_blank1.TabIndex = 18;
            this.lb_blank1.Text = "_____";
            // 
            // btn_Y
            // 
            this.btn_Y.Location = new System.Drawing.Point(365, 159);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(40, 38);
            this.btn_Y.TabIndex = 17;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = true;
            this.btn_Y.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_T
            // 
            this.btn_T.Location = new System.Drawing.Point(321, 159);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(40, 38);
            this.btn_T.TabIndex = 16;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = true;
            this.btn_T.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_R
            // 
            this.btn_R.Location = new System.Drawing.Point(273, 158);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(40, 38);
            this.btn_R.TabIndex = 15;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = true;
            this.btn_R.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // btn_E
            // 
            this.btn_E.Location = new System.Drawing.Point(227, 158);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(40, 38);
            this.btn_E.TabIndex = 14;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = true;
            this.btn_E.Click += new System.EventHandler(this.AnyButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 599);
            this.Controls.Add(this.panel_keyboard);
            this.Controls.Add(this.panel_kata);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_kata.ResumeLayout(false);
            this.panel_kata.PerformLayout();
            this.panel_keyboard.ResumeLayout(false);
            this.panel_keyboard.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb1_kata1;
        private System.Windows.Forms.Label lb_kata2;
        private System.Windows.Forms.Label lb_kata3;
        private System.Windows.Forms.Label lb_kata4;
        private System.Windows.Forms.Label lb_kata5;
        private System.Windows.Forms.TextBox txtbox_kata1;
        private System.Windows.Forms.TextBox txtbox_kata2;
        private System.Windows.Forms.TextBox txtbox_kata3;
        private System.Windows.Forms.TextBox txtbox_kata4;
        private System.Windows.Forms.TextBox txtbox_kata5;
        private System.Windows.Forms.Button btn_play;
        private System.Windows.Forms.Panel panel_kata;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Button btn_W;
        private System.Windows.Forms.Panel panel_keyboard;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_i;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Label lb_blank5;
        private System.Windows.Forms.Label lb_blank4;
        private System.Windows.Forms.Label lb_blank3;
        private System.Windows.Forms.Label lb_blank2;
        private System.Windows.Forms.Label lb_blank1;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Label lb_kataditebak;
    }
}

