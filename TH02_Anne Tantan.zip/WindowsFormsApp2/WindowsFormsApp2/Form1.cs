﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel_keyboard.Visible = false;
        }
        private void HidePanelsKata()
        {
            panel_kata.Visible = false;
        }

        List<char> guessedcharacters = new List<char>();
        private string kataterpilih;


        private void btn_play_Click(object sender, EventArgs e)
        {


            string[] kata = new string[]
            {txtbox_kata1.Text.Trim(),
            txtbox_kata2.Text.Trim(),
            txtbox_kata3.Text.Trim(),
            txtbox_kata4.Text.Trim(),
            txtbox_kata5.Text.Trim(),};

            int panjangkata = kata.Count(word => !string.IsNullOrWhiteSpace(word));
            bool cekkembar = kata.GroupBy(word => word).Any(g => g.Count() > 1);
            bool cekempty = kata.Any(string.IsNullOrWhiteSpace);

            if (cekkembar || cekempty || panjangkata != 5)
            {
                MessageBox.Show("There's still an error");
            }
            else
            {
                MessageBox.Show("Ayo Main");
                int number = new Random().Next(0, 4);
                kataterpilih = kata[number];
                guessedcharacters.AddRange(kataterpilih);
                lb_kataditebak.Text = kataterpilih;
                HidePanelsKata();
                panel_keyboard.Visible = true;
            }
        }

        private void AnyButton_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            string ubah = btn.Text.ToLower();
            char[] huruf = ubah.ToCharArray();
            for (int i = 0; i < guessedcharacters.Count; i++)
            {
                if (guessedcharacters[i] == huruf[0])
                {
                    guessedcharacters[i] = '0';
                    if (i == 0)
                    {
                        lb_blank1.Text = btn.Text;
                    }
                    else if (i == 1)
                    {
                        lb_blank2.Text = btn.Text;
                    }
                    else if (i == 2)
                    {
                        lb_blank3.Text = btn.Text;
                    }
                    else if (i == 3)
                    {
                        lb_blank4.Text = btn.Text;
                    }
                    else if (i == 4)
                    {
                        lb_blank5.Text = btn.Text;
                    }
                    break;
                }
            }

            int z = 0;
            for (int j = 0;j < guessedcharacters.Count;j++)
            {
                if (guessedcharacters[j] == '0')
                {
                    z++;
                }
            }
                if (z == 5)
            {
                MessageBox.Show("Selesai");
            }
        }

        //    int panjangkata = 0;
        //    foreach (string word in kata)
        //    {
        //        if (word != null && word != " ")
        //        {
        //            panjangkata++;
        //        }
        //    }

        //    bool cekkembar = false;
        //    for (int i = 0; i < kata.Length - 1; i++)
        //    {
        //        for (int j = i + 1; j < kata.Length; j++)
        //        {
        //            if (kata[i] == kata[j])
        //            {
        //                cekkembar = true;
        //                break;
        //            }
        //        }
        //    }
        //    bool cekempty = kata.Any(string.IsNullOrWhiteSpace);

        //    if (cekkembar || cekempty || panjangkata != 5)
        //    {
        //        MessageBox.Show("There's still an error");
        //    }


        //    else
        //    {
        //        MessageBox.Show("Ayo Main");
        //        int number = 0;
        //        Random rnd = new Random();
        //        number = rnd.Next(1,5)-1;
        //        kataterpilih = kata[number];
        //        char[] masuklist = kataterpilih.ToArray();
        //        for (int i = 0; i < masuklist.Length; i++)
        //        {
        //            guessedcharacters.Add(masuklist[i]);
        //        }
        //        lb_kataditebak.Text = kataterpilih;
        //        HidePanelsKata();
        //        panel_keyboard.Visible = true;

        //    }
        //}

        //private void AnyButton_Click(object sender, EventArgs e)
        //{
        //    Button btn = sender as Button;
        //    for (int i = 0; i < guessedcharacters.Count; i++)
        //    {
        //        guessedcharacters[i] = '0';
        //        if (i == 0)
        //            {
        //               lb_blank1.Text = btn.Text;
        //           }
        //            else if (i == 1)
        //            {
        //              lb_blank2.Text = btn.Text;
        //            }
        //           else if (i == 2)
        //            {
        //                lb_blank3.Text = btn.Text;
        //           }
        //           else if (i == 3)
        //           {
        //               lb_blank4.Text = btn.Text;
        //           }
        //        else if (i == 4)
        //        {
        //            lb_blank5.Text = btn.Text;
        //        }
        //    }

        //    int z = 0;
        //    for (int j = 0;j < guessedcharacters.Count; j++)
        //    {
        //        if (guessedcharacters[j] == 0)
        //        {
        //            z++;
        //        }
        //    }
        //    if (z == 5)
        //    {
        //        MessageBox.Show("Selesai");
        //    }



        //char buttonLetter = btn.Name[btn.Name.Length - 1];

        //if (kataterpilih.Contains(buttonLetter))
        //    for (int i = 0; i < kataterpilih.Length; i++)
        //    {
        //        if (kataterpilih[i] == buttonLetter)
        //        {
        //            guessedCharacters[i] = buttonLetter;
        //        }
        //    }








        //if (btn != null)
        //{
        //    char tebak = btn.Text[0];

        //    for (int i = 0; i < kataterpilih.Length; i++)
        //    {
        //        if (i == 0)
        //        {
        //            lb_blank1.Text = btn.Text;
        //        }
        //        else if (i == 1)
        //        {
        //            lb_blank2.Text = btn.Text;
        //        }
        //        else if (i == 2)
        //        {
        //            lb_blank3.Text = btn.Text;
        //        }
        //        else if (i == 3)
        //        {
        //            lb_blank4.Text = btn.Text;
        //        }


        //    }

        //}


    }
}
    


    



